﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(MonsterPatrol))]
public class EnemyChase : MonoBehaviour
{

    public Transform player;
    public float playerDistance;
    public float rotationDampling;
    public float moveSpeed;
    public float lookDistance;
    public float chaseDistance;
    public float stopChaseDistance;
    MonsterPatrol MP;

    public Transform Food;
    public float FoodDistance;
    public float RotatetoDamp;
    public float LookatFood;


    private void Start()
    {
        MP = GetComponent<MonsterPatrol>();
        MP.enabled = true;
        pausechasefood = 2f;
    }

    void Update()
    {
            playerDistance = Vector3.Distance(player.position, transform.position);
            FoodDistance = Vector3.Distance(Food.position, transform.position);
            MP.enabled = true;
            
            
            if (playerDistance < lookDistance && playerDistance > FoodDistance)
            {
                MP.enabled = false;
                lookAtPlayer();
            }


            if(playerDistance > lookDistance && playerDistance < FoodDistance)
            {
                 LookingAttheFood();
                 pausechasefood -= Time.deltaTime;

                 if(pausechasefood <= 0)
                 {
                        ChaseFood();
                 }
                    
            }

            if (playerDistance < chaseDistance && playerDistance < FoodDistance)
            {

                chase();

                if (playerDistance > stopChaseDistance)
                {
                    
                }
            }

            

        }
    

    void lookAtPlayer()
    {

        Quaternion rotation = Quaternion.LookRotation(player.position - transform.position);
        transform.rotation = Quaternion.Slerp(transform.rotation, rotation, Time.deltaTime * rotationDampling);

    }

    void chase()
    {

        transform.Translate(Vector3.forward * moveSpeed * Time.deltaTime);

    }

    void LookingAttheFood()
    {
        Quaternion rotation = Quaternion.LookRotation(Food.position - transform.position);
        transform.rotation = Quaternion.Slerp(transform.rotation, rotation, Time.deltaTime * LookatFood);
    }

    void ChaseFood()
    {
        transform.Translate(Vector3.forward * moveSpeed * Time.deltaTime);
    }
}

